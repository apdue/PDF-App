package com.example.pdfjitpekc.model

data class SearchResult(
    val file: PdfFile,
    val matchCount: Int
) 